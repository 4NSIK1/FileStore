# Mac_Live_Extract_v0.1 
# Running processes  - Done
# file handles open -Done
# live network connections - Done
# 

import os
import subprocess
import sys
from datetime import datetime
import csv
from collections import OrderedDict

#extract running processes to csv file and save in execution folder
headers = ['pid', 'ppid', 'user', 'state', 'proc_start', 'runtime', 'cmd']
output_dir=os.getcwd()

now = datetime.now()
dt_string = now.strftime("%d%m%Y_%H%M%S")
file_out_ps="ps_"+dt_string+".csv"
output_file_ps=os.path.join(output_dir,file_out_ps)
ps_out, e = subprocess.Popen(["ps", "-Ao", "pid,ppid,user,stat,lstart,time,command"], stdout=subprocess.PIPE).communicate()

if e:
    pass
else:
    pslist = ps_out.decode('utf-8').split('\n')
    with open(output_file_ps,"w") as f:
        csv_ps = csv.writer(f,delimiter=",",lineterminator="\r")  
        csv_ps.writerow(headers)
        for p in pslist:
            if "PID" not in p and len(p) > 0:
                item = [x.lstrip(' ') for x in filter(None, p.split(' '))]
                pid = item[0]
                ppid = item[1]
                user = item[2]
                state = item[3]
                proc_start = ' '.join(item[5:9])  #.isoformat()
                runtime = item[9]
                cmd = ' '.join(item[10:])
                line = [pid, ppid, user, state, proc_start, runtime, cmd]
                csv_ps.writerow(line)

#extract live network connections
headers = ['protocol', 'recv_q', 'send_q', 'src_ip', 'src_port', 'dst_ip', 'dst_port', 'state']
file_out_net="net_"+dt_string+".csv"
output_file_net=os.path.join(output_dir,file_out_net)
netstat_out, e = subprocess.Popen(["netstat", "-f", "inet", "-n"], stdout=subprocess.PIPE).communicate()
if e:
    pass
else:
    netstat = netstat_out.decode().split('\n')
    with open(file_out_net,"w") as f:
        csv_net = csv.writer(f,delimiter=",",lineterminator="\r")
        csv_net.writerow(headers)
        for l in netstat:
            if not (l.startswith("Active") or l.startswith("Proto") or len(l) == 0):
                item = [x.lstrip(' ') for x in filter(None, l.split(' '))]
                protocol = item[0]
                recv_q = item[1]
                send_q = item[2]
                try:
                    src_ip = '.'.join(item[3].split('.')[0:4])
                except Exception:
                    src_ip = "ERROR"
                try:
                    src_port = item[3].split('.')[-1]
                except Exception:
                    src_port = "ERROR"

                try:
                    dst_ip = '.'.join(item[4].split('.')[0:4])
                except Exception:
                    dst_ip = "ERROR"
                try:
                    dst_port = item[4].split('.')[-1]
                except Exception:
                    dst_port = "ERROR"

                if len(item) == 6:
                    state = item[5]
                else:
                    state = ""

                line = [protocol, recv_q, send_q, src_ip, src_port, dst_ip, dst_port, state]
                csv_net.writerow(line)

#Extract current file handles
headers = ['cmd', 'pid', 'ppid', 'user', 'file_descriptor', 'type', 'device', 'size', 'node', 'access', 'name']
file_out_of="of_"+dt_string+".csv"
output_file_of=os.path.join(output_dir,file_out_of)

names = OrderedDict(zip('cpRLftDsian', 'command pid ppid user fd type device_no size inode access name'.split()))

lsof = subprocess.Popen(["lsof", "-n", "-P", "-F{}0".format(''.join(names))], stdout=subprocess.PIPE, bufsize=-1)
with open(output_file_of,"w") as f:
    csv_of = csv.writer(f,delimiter=",",lineterminator="\r")
    csv_of.writerow(headers)
    for line in lsof.stdout:
            
        try:
            fields = {f[:1].decode('ascii', 'strict'): f[1:].decode() for f in line.split(b'\0') if f.rstrip(b'\n')}
        except UnicodeDecodeError:
            fields = {f[:1].decode('ascii', 'strict'): f[1:] for f in line.split(b'\0') if f.rstrip(b'\n')}
        if 'p' in fields:
            process_info = fields
        elif 'f' in fields:
            fields.update(process_info)
            result = OrderedDict((name, fields.get(id)) for id, name in names.items())
            line = [v for k, v in result.items()]
    
            csv_of.writerow(line)
    
    lsof.communicate()


